const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.EightDir,
		C3.Behaviors.scrollto
	];
};
self.C3_JsPropNameTable = [
	{"8Direction": 0},
	{ScrollTo: 0},
	{Sprite: 0},
	{Sprite2: 0}
];

self.InstanceType = {
	Sprite: class extends self.ISpriteInstance {},
	Sprite2: class extends self.ISpriteInstance {}
}